Original Pac-Man Sound Effects

Wav Files - recorded at 44100 khz/16 bit/mono
MP3's - created from above listed wave files at a bitrate of 160 Kbps

Both wave and mp3 files have been volume normalized.

Ripped by Twisty on December 23, 2002
Copyrighted by Namco - not for commercial use *whatsoever*.

Enjoy :D

